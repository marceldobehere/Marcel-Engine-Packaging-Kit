﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace MEPKG_Installer
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Making Program Folder.");
            Directory.CreateDirectory(@"C:\Program Files\MarcelEngine");
            if (File.Exists(@"C:\Program Files\MarcelEngine\MEPKG Opener.exe"))
            {
                File.Delete(@"C:\Program Files\MarcelEngine\MEPKG Opener.exe");
            }
            Console.WriteLine("Copying Opener Program.");
            File.Copy(@"files\MEPKG Opener.exe", @"C:\Program Files\MarcelEngine\MEPKG Opener.exe");
            Console.WriteLine("Registering File Extension. (.mepkg)");
            RegisterForFileExtension(".mepkg", @"C:\Program Files\MarcelEngine\MEPKG Opener.exe");
            Console.WriteLine("Installed!");
            System.Threading.Thread.Sleep(1000);
        }
        private static void RegisterForFileExtension(string extension, string applicationPath)
        {
            Microsoft.Win32.RegistryKey FileReg = Microsoft.Win32.Registry.CurrentUser.CreateSubKey("Software\\Classes\\" + extension);
            //FileReg.CreateSubKey("shell\\open\\command").SetValue("", applicationPath + " %1");
            FileReg.CreateSubKey(@"shell\open\command").SetValue("", $"\"{applicationPath}\" \"%1\"");
            FileReg.Close();

            SHChangeNotify(0x08000000, 0x0000, IntPtr.Zero, IntPtr.Zero);
        }
        [DllImport("shell32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern void SHChangeNotify(uint wEventId, uint uFlags, IntPtr dwItem1, IntPtr dwItem2);
    }
}

