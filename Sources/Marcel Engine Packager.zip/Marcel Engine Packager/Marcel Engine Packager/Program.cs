﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.IO.Compression;

namespace Marcel_Engine_Packager
{
    class Program
    {
        [STAThread]
        static void Main(string[] args)
        {
            Console.Title = "Marcel Engine Packager";
            Console.WriteLine("This Program will Package up your Game made in the Marcel Engine.");
            Console.WriteLine("\nNote: The whole folder in which the exe is in, will get packaged up.");
            Console.WriteLine("Press Enter to select your exe...");

            Console.ReadLine();

            string pathToExe = OpenFile();
            string pathToFolder = Path.GetDirectoryName(pathToExe);
            string parentOfFolder = Directory.GetParent(Path.GetDirectoryName(pathToExe)).FullName;
            //string pathToFolder2 = Directory.GetParent(pathToExe).FullName;

            Console.WriteLine($"EXE: {pathToExe}");
            Console.WriteLine($"Folder: {pathToFolder}");
            Console.WriteLine($"Parent: {parentOfFolder}");

            Console.WriteLine("Please Enter a Name for your Game:");
            string name = Console.ReadLine();


            ZipFile.CreateFromDirectory(pathToFolder, $@"{parentOfFolder}\{name}.mepkg");
        }

        


        static string OpenFile()
        {
            /*
            using (var fbd = new FolderBrowserDialog())
            {
                DialogResult result = fbd.ShowDialog();

                if (result == DialogResult.OK)
                {
                    return fbd.SelectedPath;
                }
                return "";
            }
            */


            
            OpenFileDialog openFileDialog1 = new OpenFileDialog
            {
                //InitialDirectory = @"D:\",
                Title = "Select Your compiled Game...",

                CheckFileExists = true,
                CheckPathExists = true,

                DefaultExt = "exe",
                Filter = "exe files (*.exe)|*.exe",
                FilterIndex = 1,
                RestoreDirectory = true,

                ReadOnlyChecked = true,
                ShowReadOnly = true
            };

            if (openFileDialog1.ShowDialog() == DialogResult.OK)
            {
                return openFileDialog1.FileName;
            }
            return "";
            
        }
    }
}
