﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Win32;
using System;
using System.IO;
using System.Runtime.InteropServices;
using System.IO.Compression;
using System.Diagnostics;

namespace MEPKG_Opener
{
    class Program
    {
        [DllImport("User32.dll", CallingConvention = CallingConvention.StdCall, SetLastError = true)]
        [return: MarshalAs(UnmanagedType.Bool)]
        private static extern bool ShowWindow([In] IntPtr hWnd, [In] int nCmdShow);

        [STAThread]
        static void Main()
        {
            Console.WriteLine("Opening File...");
            string filePath = "";

            IntPtr handle = Process.GetCurrentProcess().MainWindowHandle;

            ShowWindow(handle, 6);

            foreach (string temp in System.Environment.GetCommandLineArgs())
            {
                Console.WriteLine("Path: " + temp);
                if (System.IO.File.Exists(temp) && temp.Contains(".mepkg"))
                {
                    filePath = temp;
                }
            }

            if (filePath != "")
            {
                Console.WriteLine($"Filepath: {filePath}");
                string path = Path.GetDirectoryName(filePath) + @"\Temp";
                path = @"C:\Temp\MEPKG";
                if (Directory.Exists(path))
                {
                    Directory.Delete(path, true);
                }
                ZipFile.ExtractToDirectory(filePath, path);
                Process x = new Process();
                x.StartInfo.FileName = path + @"\Marcel Engine.exe";
                x.StartInfo.WorkingDirectory = path;
                x.Start();
                x.WaitForExit();
                System.Threading.Thread.Sleep(500);
                File.Delete(filePath);
                ZipFile.CreateFromDirectory(path, filePath);
                Directory.Delete(path, true);
            }



            Console.WriteLine("Done...");

            //Console.ReadLine();

            //ZipFile.CreateFromDirectory(pathToFolder, $@"{parentOfFolder}\{name}.mepkg");
        }


    private static void RegisterForFileExtension(string extension, string applicationPath)
        {
            RegistryKey FileReg = Registry.CurrentUser.CreateSubKey("Software\\Classes\\" + extension);
            FileReg.CreateSubKey("shell\\open\\command").SetValue("", applicationPath + " %1");
            FileReg.Close();

            SHChangeNotify(0x08000000, 0x0000, IntPtr.Zero, IntPtr.Zero);
        }
        [DllImport("shell32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        public static extern void SHChangeNotify(uint wEventId, uint uFlags, IntPtr dwItem1, IntPtr dwItem2);
    }
}
